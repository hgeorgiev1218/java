package com.georgiev.ewapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import com.georgiev.ewapp.models.Degree;
import com.georgiev.ewapp.models.StudentMember;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    private static final List<StudentMember> students=new ArrayList<>();

    static{
        students.add(new StudentMember(UUID.randomUUID().toString(), "John", "Doe", Degree.BACHELOR));
        students.add(new StudentMember(UUID.randomUUID().toString(), "Jane", "Doe", Degree.MASTER));
        students.add(new StudentMember(UUID.randomUUID().toString(), "Oliver", "Handle", Degree.ACADEMIC));
        students.add(new StudentMember(UUID.randomUUID().toString(), "Sammy", "Smith", Degree.FOUNDATION));
    }

    public List<StudentMember> getAllStudent(){
        return students;
    }
}