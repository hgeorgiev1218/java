package com.georgiev.ewapp.data;

import com.georgiev.ewapp.models.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
