package com.georgiev.ewapp.controllers;

import java.util.List;

import com.georgiev.ewapp.models.StudentMember;
import com.georgiev.ewapp.service.StudentService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/students")
public class StudentRestController {

    private final StudentService studentService;

    public StudentRestController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping
    public List<StudentMember> getAllStudent(){
        return studentService.getAllStudent();
    }
}