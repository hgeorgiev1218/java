package com.georgiev.ewapp.service;

import java.util.ArrayList;
import java.util.List;

import com.georgiev.ewapp.data.CourseRepository;
import com.georgiev.ewapp.models.Course;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
    public final CourseRepository courseRepository;

    public CourseService(CourseRepository courseRepository) {this.courseRepository = courseRepository;}

    public List<Course> getAllCourses(){return courseRepository.findAll();}
}