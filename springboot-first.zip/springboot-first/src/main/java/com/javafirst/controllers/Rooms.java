package com.javafirst.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class Rooms {
}
