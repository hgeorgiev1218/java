package com.georgiev.ewapp.controllers;

import java.util.ArrayList;
import java.util.List;

import com.georgiev.ewapp.models.Course;
import com.georgiev.ewapp.service.CourseService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/courses")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping
    public String getAllCourses(Model model){
        model.addAttribute("courses", courseService.getAllCourses());
        return "courses";
    }
}