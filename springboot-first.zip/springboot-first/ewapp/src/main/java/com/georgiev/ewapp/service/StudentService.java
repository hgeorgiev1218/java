package com.georgiev.ewapp.service;

import java.util.ArrayList;
import java.util.List;

import com.georgiev.ewapp.data.StudentRepository;
import com.georgiev.ewapp.models.Student;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
    public final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {this.studentRepository = studentRepository;}

    public List<Student> getAllStudents(){return studentRepository.findAll();}
}