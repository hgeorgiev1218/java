package com.georgiev.ewapp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Students")
public class Student {
    @Id
    @Column(name="Student_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    @Column(name="FIRST_NAME")
    private String firstname;
    @Column(name="LAST_NAME")
    private String lastname;
    @Column(name="Degree")
    private String degree;

    public Student() {
    }

    public Student(String id, String firstname, String lastname, String degree) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.degree = degree;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {this.id = id;}

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getDegree() {
        return degree;
    }

    public void getDegree(String degree) {
        this.degree = degree;
    }
}
