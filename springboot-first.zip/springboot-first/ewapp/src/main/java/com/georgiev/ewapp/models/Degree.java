package com.georgiev.ewapp.models;

public enum Degree {
    BACHELOR, MASTER, ACADEMIC, FOUNDATION;

    public String toString() {
        switch (this) {
            case BACHELOR:
                return "Bachelor";
            case MASTER:
                return "Master";
            case ACADEMIC:
                return "Academic";
            case FOUNDATION:
                return "Foundation";
        }
        return "";
    }
}