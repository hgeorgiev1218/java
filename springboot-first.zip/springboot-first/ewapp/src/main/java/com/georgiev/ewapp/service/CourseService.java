package com.georgiev.ewapp.service;

import java.util.ArrayList;
import java.util.List;

import com.georgiev.ewapp.models.Course;
import org.springframework.stereotype.Service;

@Service
public class CourseService {

    private static final List<Course> courses=new ArrayList<>();

    static{
        for (int i=0;i<10;i++){
            courses.add(new Course(i,"Course "+i, "R"+i,"Q"));
        }
    }
    public List<Course> getAllCourses() {return courses;}
}
